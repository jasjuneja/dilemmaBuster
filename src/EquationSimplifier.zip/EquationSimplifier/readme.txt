EntryPoint:
Main.java
 1. Parses Json File(Needs Filepath)
 2. Transformer (Tranforms the Equation, prints entire value against "x")

Run Main.java to test

Prerequisites

Maven
Java

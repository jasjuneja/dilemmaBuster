package com.cleartax.EquationSimplifier;

public class Transformer {

    public void transform(TreeNode root, TreeNode parent, TreeNode untouchedRoot) {

        if (root == null || !root.isOperator) {
            return;
        }

        if (root.isOperator && isAnyChildOperator(root) &&
                !(isChildVariable(root))) {
            if (!root.left.isOperator) {
                move(untouchedRoot, root, root.left);
                root.setLeft(null);
                if (parent.getLeft() == root) {
                    parent.setLeft(root.getRight());
                    transform(parent.getLeft(), parent, untouchedRoot);
                } else {
                    parent.setRight(root.getRight());
                    transform(parent.getRight(), parent, untouchedRoot);
                }
            } else {
                move(untouchedRoot, root, root.getRight());
                root.setRight(null);
                if (parent.getLeft() == root) {
                    parent.setLeft(root.getLeft());
                    transform(parent.getLeft(), parent, untouchedRoot);
                } else {
                    parent.setRight(root.getLeft());
                    transform(parent.getRight(), parent, untouchedRoot);
                }
            }
        } else if (root.isOperator && !isAnyChildOperator(root) &&
                !isChildVariable(root)) {

            move(untouchedRoot, parent, root);
            if (parent.getLeft() == root) {
                parent.setLeft(null);
            } else {
                parent.setRight(null);
            }
        } else if (root.isOperator && isChildVariable(root)) {
            if (root.getLeft().data.equals("x")) {
                move(untouchedRoot, root, root.getRight());
                root.setRight(null);
                if (parent.getLeft() == root) {
                    parent.setLeft(root.getLeft());
                } else {
                    parent.setRight(root.getLeft());
                }
            } else {
                move(untouchedRoot, root, root.getLeft());
                root.setLeft(null);
                if (parent.getLeft() == root) {
                    parent.setLeft(root.getRight());
                } else {
                    parent.setRight(root.getRight());
                }
            }
            root.setLeft(null);
            root.setRight(null);
        }

    }

    private boolean isChildVariable(TreeNode root) {
        return root.getLeft().getData().equals("x") || root.getRight().getData().equals("x");
    }

    private boolean isAnyChildOperator(TreeNode root) {
        return root.getLeft().isOperator || root.right.isOperator;
    }

    private void move(TreeNode root, TreeNode parent, TreeNode child) {
        TreeNode inverse = new TreeNode();
        inverse.setData(inverse(parent.getData()));
        inverse.setLeft(root.getRight());
        inverse.setRight(child);
        root.setRight(inverse);
    }

    private String inverse(String op) {
        switch (op) {

            case "*":
                return "/";
            case "+":
                return "-";
            case "-":
                return "+";
            case "/":
                return "*";
            default:
                throw new IllegalArgumentException("Invalid operator  " + op);
        }

    }


}

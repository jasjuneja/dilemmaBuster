package com.cleartax.EquationSimplifier;

class TreeNode{

    boolean isOperator;
    String data;
    TreeNode left;
    TreeNode right;

    public TreeNode() {
    }

    public TreeNode(boolean isOperator, String data, TreeNode left, TreeNode right) {
        this.isOperator = isOperator;
        this.data = data;
        this.left = left;
        this.right = right;
    }

    public boolean isOperator() {
        return isOperator;
    }

    public void setOperator(boolean operator) {
        isOperator = operator;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public TreeNode getLeft() {
        return left;
    }

    public void setLeft(TreeNode left) {
        this.left = left;
    }

    public TreeNode getRight() {
        return right;
    }

    public void setRight(TreeNode right) {
        this.right = right;
    }

    @Override
    public String toString() {
        return "TreeNode{" +
                "operation='" + isOperator + '\'' +
                ", data='" + data + '\'' +
                ", left=" + left +
                ", right='" + right + '\'' +
                '}';
    }
}


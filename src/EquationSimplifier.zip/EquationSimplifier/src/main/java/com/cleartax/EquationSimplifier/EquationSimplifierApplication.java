package com.cleartax.EquationSimplifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class EquationSimplifierApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(EquationSimplifierApplication.class, args);
	}
}

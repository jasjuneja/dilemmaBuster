package com.cleartax.EquationSimplifier;
import org.json.JSONObject;

import java.io.*;

public class Parser {

    public static void main(String[] args) throws IOException {

    }

    public TreeNode readJson(String filePath) throws IOException {

        String jsonData = readFile(filePath);
        JSONObject jsonObject = new JSONObject(jsonData);
        TreeNode root = buildTree(jsonObject);

        return root;
    }


    public String readFile(String filename) {
        String result = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(filename)));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();
            while (line != null) {
                sb.append(line);
                line = br.readLine();
            }
            result = sb.toString();
        } catch(Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    private TreeNode buildTree(JSONObject jsonObject) {
        String op = getOperator(jsonObject.getString("op"));
        Object rhs = jsonObject.get("rhs");
        Object lhs = jsonObject.get("lhs");
        TreeNode tn = new TreeNode();
        if (op != null) {
            tn.setOperator(true);
            tn.setData(op);
        }

        if (lhs instanceof JSONObject) {
            tn.setLeft(buildTree((JSONObject) lhs));
        } else {
            tn.setLeft(new TreeNode(false, String.valueOf(lhs), null, null));
        }

        if (rhs instanceof JSONObject) {
            tn.setRight(buildTree((JSONObject) rhs));
        } else {
            tn.setRight(new TreeNode(false, String.valueOf(rhs), null, null));
        }
        return tn;
    }

    private String getOperator(String op) {
        switch (op) {

            case "multiply":
                return "*";
            case "add":
                return "+";
            case "equal":
                return "=";

            case "subtract":
                return "-";
            case "divide":
                return "/";
            default:
                throw new IllegalArgumentException("Invalid operator " + op);
        }
    }


}


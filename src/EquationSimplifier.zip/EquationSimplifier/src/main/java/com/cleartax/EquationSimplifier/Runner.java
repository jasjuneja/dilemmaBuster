package com.cleartax.EquationSimplifier;

import java.io.IOException;

public class Runner {


    public static void main(String[] args) throws IOException {

        Parser parser = new Parser();
        TreeNode root = parser.readJson("src/main/resources/test.json");

        Transformer transformer = new Transformer();

        printInPretty(root);
       transformer.transform(root.getLeft(), root, root);
        System.out.println("\n=== After Transformation ===");
        printInPretty(root);
    }

    private static void printInPretty(TreeNode root) {
        if (root != null) {
            printInPretty(root.left);
            System.out.print(root.data + " ");
            printInPretty(root.right);
        }

    }
}
